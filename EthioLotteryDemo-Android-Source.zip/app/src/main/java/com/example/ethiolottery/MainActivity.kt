package com.example.ethiolottery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

private val Navy = Color(0xFF101827)
private val Panel = Color(0xFF1B2638)
private val Gold = Color(0xFFF0BE55)
private val Pale = Color(0xFFF4F6FA)
private val Green = Color(0xFF3BC58A)

enum class DrawType(val label: String, val price: Int, val durationSeconds: Long) {
    DAILY("Daily", 100, 24 * 60 * 60L),
    WEEKLY("Weekly", 50, 7 * 24 * 60 * 60L),
    MONTHLY("Monthly", 50, 30 * 24 * 60 * 60L)
}
data class Ticket(val draw: DrawType, val number: String, val purchasedAt: Long)
data class DrawResult(val draw: DrawType, val number: String, val proof: String, val timestamp: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EthioLotteryApp() }
    }
}

@Composable
fun EthioLotteryApp() {
    var selectedTab by remember { mutableStateOf("Play") }
    var selectedDraw by remember { mutableStateOf(DrawType.DAILY) }
    var manualNumber by remember { mutableStateOf("") }
    var tickets by remember { mutableStateOf(listOf<Ticket>()) }
    var results by remember { mutableStateOf(listOf<DrawResult>()) }
    var message by remember { mutableStateOf("Welcome! This demo uses simulated tickets only.") }
    var adminMode by remember { mutableStateOf(false) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, secondary = Green, background = Navy, surface = Panel,
        onPrimary = Navy, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Navy,
            topBar = {
                Column(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 20.dp, vertical = 16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(42.dp).background(Gold, RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) { Text("6", color = Navy, fontSize = 26.sp, fontWeight = FontWeight.Black) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("ETHIO LOTTERY", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.White)
                            Text("Choose a number. Try your luck.", fontSize = 12.sp, color = Color.LightGray)
                        }
                        Text("DEMO", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Play", "My Tickets", "Results", "Admin").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = { Text(when(tab) { "Play" -> "◉"; "My Tickets" -> "▣"; "Results" -> "✓"; else -> "⚙" }) },
                            label = { Text(tab, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold, selectedTextColor = Gold,
                                indicatorColor = Navy, unselectedTextColor = Color.LightGray
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                Spacer(Modifier.height(12.dp))
                Text(message, color = Gold, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                when (selectedTab) {
                    "Play" -> PlayScreen(
                        selectedDraw, { selectedDraw = it; manualNumber = "" },
                        manualNumber, { manualNumber = it },
                        tickets, now,
                        onBuy = { draw, number ->
                            if (tickets.any { it.draw == draw && it.number == number }) {
                                message = "You already own $number in this draw."
                            } else {
                                // In a real app, uniqueness must be enforced by a trusted backend.
                                tickets = tickets + Ticket(draw, number, System.currentTimeMillis())
                                message = "Demo ticket purchased: $number (${draw.price} ETB simulated)."
                                manualNumber = ""
                            }
                        }
                    )
                    "My Tickets" -> TicketsScreen(tickets)
                    "Results" -> ResultsScreen(results)
                    else -> AdminScreen(
                        tickets, results, adminMode, { adminMode = it },
                        onDraw = { draw ->
                            val winning = Random.nextInt(0, 1_000_000).toString().padStart(6, '0')
                            val time = System.currentTimeMillis()
                            val proof = sha256("${draw.name}|$winning|$time|ETHIO-LOTTERY-DEMO")
                            results = listOf(DrawResult(draw, winning, proof, time)) + results
                            message = "Demo result published for ${draw.label}: $winning"
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun PlayScreen(
    selectedDraw: DrawType,
    onDrawSelected: (DrawType) -> Unit,
    manualNumber: String,
    onNumberChange: (String) -> Unit,
    tickets: List<Ticket>,
    now: Long,
    onBuy: (DrawType, String) -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
        item {
            Text("Pick your draw", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DrawType.values().forEach { draw ->
                    val chosen = draw == selectedDraw
                    Column(
                        Modifier.weight(1f).background(if (chosen) Gold else Panel, RoundedCornerShape(16.dp))
                            .clickable { onDrawSelected(draw) }.padding(12.dp)
                    ) {
                        Text(draw.label, color = if (chosen) Navy else Color.White, fontWeight = FontWeight.Bold)
                        Text("${draw.price} ETB", color = if (chosen) Navy else Gold, fontSize = 17.sp, fontWeight = FontWeight.Black)
                        Text("Fixed price", color = if (chosen) Navy else Color.LightGray, fontSize = 10.sp)
                    }
                }
            }
        }
        item {
            val remaining = countdownSeconds(selectedDraw, now)
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(18.dp)) {
                Text("${selectedDraw.label.uppercase()} DRAW CLOSES IN", color = Color.LightGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(formatCountdown(remaining), color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Black)
                Text("Demo countdown • closes on a rolling timer", color = Color.LightGray, fontSize = 11.sp)
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(18.dp)) {
                Text("Choose your 6-digit number", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("000000–999999. Leading zeros are allowed.", color = Color.LightGray, fontSize = 12.sp)
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = manualNumber,
                    onValueChange = { value -> if (value.length <= 6 && value.all(Char::isDigit)) onNumberChange(value) },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("e.g. 004281") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedBorderColor = Gold, unfocusedBorderColor = Color.Gray,
                        focusedLabelColor = Gold, cursorColor = Gold
                    )
                )
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        var number: String
                        var tries = 0
                        do {
                            number = Random.nextInt(0, 1_000_000).toString().padStart(6, '0')
                            tries++
                        } while (tickets.any { it.draw == selectedDraw && it.number == number } && tries < 1_100_000)
                        onNumberChange(number)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF34445D))
                ) { Text("Generate random available number", color = Color.White) }
                Spacer(Modifier.height(8.dp))
                if (manualNumber.length == 6) {
                    val owned = tickets.any { it.draw == selectedDraw && it.number == manualNumber }
                    Text(if (owned) "Already taken by you in this demo" else "Number appears available in this demo",
                        color = if (owned) Color(0xFFFF8888) else Green, fontSize = 12.sp)
                }
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { if (manualNumber.length == 6) onBuy(selectedDraw, manualNumber) },
                    enabled = manualNumber.length == 6 && !tickets.any { it.draw == selectedDraw && it.number == manualNumber },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Navy)
                ) { Text("Simulate ticket purchase • ${selectedDraw.price} ETB", fontWeight = FontWeight.Bold) }
                Text("No real payment is taken.", color = Color.LightGray, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }
        item {
            Text("Rules", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text("• One number per player per draw in this local demo.\n• The same number can be used in another draw type.\n• Purchases and data are stored in memory and reset when the app closes.",
                color = Color.LightGray, fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}

@Composable
fun TicketsScreen(tickets: List<Ticket>) {
    Column(Modifier.fillMaxSize()) {
        Text("My tickets", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("${tickets.size} ticket(s) in this demo", color = Color.LightGray)
        Spacer(Modifier.height(12.dp))
        if (tickets.isEmpty()) EmptyState("No tickets yet", "Choose a draw and simulate your first ticket.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(tickets.reversed()) { ticket ->
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(ticket.draw.label + " draw", color = Color.LightGray, fontSize = 12.sp)
                        Text(ticket.number, color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    }
                    Text("${ticket.draw.price} ETB", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ResultsScreen(results: List<DrawResult>) {
    Column(Modifier.fillMaxSize()) {
        Text("Draw results", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Demo results with SHA-256 proof strings", color = Color.LightGray, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        if (results.isEmpty()) EmptyState("No results published", "The admin demo can publish a sample result.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(results) { result ->
                Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(16.dp)) {
                    Text(result.draw.label + " draw", color = Color.LightGray)
                    Text(result.number, color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Black)
                    Text("Created: " + SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(result.timestamp)), color = Color.LightGray, fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Proof hash", color = Green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(result.proof, color = Color.LightGray, fontSize = 10.sp)
                    Text("Demo proof only; not independently audited.", color = Color(0xFFFFC6A8), fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
fun AdminScreen(
    tickets: List<Ticket>,
    results: List<DrawResult>,
    adminMode: Boolean,
    setAdminMode: (Boolean) -> Unit,
    onDraw: (DrawType) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Text("Admin dashboard", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Local demo controls • no authentication", color = Color(0xFFFFC6A8), fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Tickets", tickets.size.toString(), Modifier.weight(1f))
            StatCard("Simulated sales", "${tickets.sumOf { it.draw.price }} ETB", Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Admin controls", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Switch(checked = adminMode, onCheckedChange = setAdminMode)
        }
        Text(if (adminMode) "Controls unlocked for this demo." else "Turn on to enable sample result publishing.", color = Color.LightGray, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        DrawType.values().forEach { draw ->
            Button(
                onClick = { onDraw(draw) },
                enabled = adminMode,
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Panel, disabledContainerColor = Color(0xFF283244))
            ) { Text("Publish demo ${draw.label.lowercase()} result", color = if (adminMode) Gold else Color.Gray) }
        }
        Spacer(Modifier.height(8.dp))
        Text("${results.size} result(s) published in this session.", color = Color.LightGray, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        Text("Before real launch", color = Gold, fontWeight = FontWeight.Bold)
        Text("Add authenticated admin access, server-side ticket locking, permanent database storage, trusted random draws, audit logs, legal review, and compliant payment integration.",
            color = Color.LightGray, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(14.dp)).padding(16.dp)) {
        Text(label, color = Color.LightGray, fontSize = 12.sp)
        Text(value, color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
fun EmptyState(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(top = 44.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("◎", color = Gold, fontSize = 40.sp)
        Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Color.LightGray, fontSize = 12.sp)
    }
}

fun countdownSeconds(draw: DrawType, now: Long): Long {
    val duration = draw.durationSeconds * 1000L
    val start = (now / duration) * duration
    val end = start + duration
    return ((end - now) / 1000L).coerceAtLeast(0)
}

fun formatCountdown(total: Long): String {
    val days = total / 86400
    val hours = (total % 86400) / 3600
    val minutes = (total % 3600) / 60
    val seconds = total % 60
    return if (days > 0) String.format("%dd %02dh %02dm %02ds", days, hours, minutes, seconds)
    else String.format("%02dh %02dm %02ds", hours, minutes, seconds)
}

fun sha256(value: String): String {
    val bytes = MessageDigest.getInstance("SHA-256").digest(value.toByteArray())
    return bytes.joinToString("") { "%02x".format(it) }
}
